//
//  LoginChecker.swift
//  TextFieldError
//
//  Created by Immature Inc on 28/04/2020.
//  Copyright © 2020 AnthonyDesignCode.io. All rights reserved.
//

import Foundation
import SwiftUI
import Combine

class LoginChecker: ObservableObject {

let textLimit = 16
    var full = false
    var login = "" {
        willSet {
            if newValue.count > textLimit {
                full = true
            } else {
                full = false
            }
        }
        didSet {
            if full {
                login = oldValue
            } else {
                login = phoneFormatter(login)
            }
            self.objectWillChange.send()
        }
    }
    
    func phoneFormatter (_ login: String) -> String {
        let numbers = onlyNumbers(login)
        var newValue = numbers.first == "7" ? String(numbers.dropFirst()) : numbers
        
        if numbers.count > 1 {
            newValue.insert("+", at: newValue.startIndex)
            newValue.insert("7", at: newValue.index(newValue.startIndex, offsetBy: 2))
            newValue.insert(" ", at: newValue.index(newValue.startIndex, offsetBy: 4))
            if numbers.count > 6 {
                newValue.insert(" ", at: newValue.index(newValue.startIndex, offsetBy: 8))
                if numbers.count > 10 {
                    newValue.insert(" ", at: newValue.index(newValue.startIndex, offsetBy: 11))
                    if numbers.count > 12 {
                        newValue.insert(" ", at: newValue.index(newValue.startIndex, offsetBy: 13))
                    }
                }
            }
        }
        
        return newValue
    }
}

func onlyNumbers(_ item: String) -> String {
    var numbers = ""
    for i in item {
        if checkNumber(i) {
            numbers += String(i)
        }
    }
    return numbers
}

func checkNumber (_ symbol: Character) -> Bool {
    var result = false
    for i in 0...9{
        if (i == symbol.wholeNumberValue) {
            result = true
            break
        }
    }
    return result
}


class CodeChecker: ObservableObject {
    var full = false
    var code = "" {
        willSet {
            if newValue.count > 4 {
                self.full = true
            } else {
                self.full = false
            }
        }
        didSet {
            if full {
                self.code = oldValue
            }
            self.objectWillChange.send()
        }
    }
}
