//
//  ContentView.swift
//  TextFieldError
//
//  Created by Immature Inc on 28/04/2020.
//  Copyright © 2020 AnthonyDesignCode.io. All rights reserved.
//

import SwiftUI

struct ContentView: View {
     @ObservedObject var loginChecker = LoginChecker()
    
    var body: some View {
        HStack {
            TextField("Enter Phone Number", text: $loginChecker.login)
                .textContentType(.telephoneNumber)
                .keyboardType(.numberPad)
                .disableAutocorrection(true)
        }.padding()
    }
}

